import React from "react";
// import DateTime from "./date_time";
// import Hook from "./Hook";
// import UpdateTime from "./update_time";

// import Todolist from "./ToDoList"; 

// import IncDec from "./IncDec";

// import Profile from "./Profile";

// import Navbar from "./Navbar";

import Paging from "./Psging";;

const App = () => {
  return (
    <>
      {/* <DateTime />
      <Hook />
      <UpdateTime /> */}
      {/* <Todolist /> */}
      {/* <IncDec /> */}
      {/* <Navbar title="Git Project" icon="fa fa-github"/>
      <Profile /> */}
      <Paging />
    </>
  );
};

export default App;
